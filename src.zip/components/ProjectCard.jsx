import React from 'react';
import GlassCard from './GlassCard';

const ProjectCard = ({ title, description, tech, live, github, cover }) => {
  return (
    <GlassCard hover={true} className="h-full">
      <div className="aspect-video bg-gradient-to-br from-forest-400 to-forest-600 rounded-lg mb-6 flex items-center justify-center">
        <img 
          src={cover} 
          alt={title}
          className="w-full h-full object-cover rounded-lg"
          onError={(e) => {
            e.target.style.display = 'none';
            e.target.nextSibling.style.display = 'flex';
          }}
        />
        <div className="hidden w-full h-full items-center justify-center text-white text-2xl font-semibold">
          {title}
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-white mb-3">
        {title}
      </h3>
      
      <p className="text-white/80 mb-4 line-clamp-3">
        {description}
      </p>
      
      <div className="flex flex-wrap gap-2 mb-6">
        {tech.map((technology, index) => (
          <span 
            key={index}
            className="px-3 py-1 text-sm bg-white/20 text-white rounded-full backdrop-blur-sm"
          >
            {technology}
          </span>
        ))}
      </div>
      
      <div className="flex gap-4 mt-auto">
        <a 
          href={live}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 text-center py-2 px-4 bg-forest-500 hover:bg-forest-400 text-white rounded-lg transition-colors"
        >
          Live Demo
        </a>
        <a 
          href={github}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 text-center py-2 px-4 border border-white/30 hover:bg-white/10 text-white rounded-lg transition-colors"
        >
          GitHub
        </a>
      </div>
    </GlassCard>
  );
};

export default ProjectCard;