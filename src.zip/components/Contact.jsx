import React from 'react';
import SectionHeader from './SectionHeader';
import ContactForm from './ContactForm';
import GlassCard from './GlassCard';
import { site } from '../content/site.config';

const Contact = () => {
  return (
    <section id="contact" className="py-20 relative">
      <div className="container mx-auto px-6">
        <SectionHeader 
          title="Get In Touch" 
          subtitle="Let's connect and discuss opportunities or just say hello!"
        />
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-8">
            <GlassCard>
              <h3 className="text-2xl font-semibold text-white mb-6">
                Contact Information
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-forest-400 rounded-full mr-4 flex-shrink-0"></div>
                  <div>
                    <p className="text-white/60 text-sm">Email</p>
                    <a 
                      href={`mailto:${site.links.email}`}
                      className="text-white hover:text-forest-300 transition-colors"
                    >
                      {site.links.email}
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-forest-400 rounded-full mr-4 flex-shrink-0"></div>
                  <div>
                    <p className="text-white/60 text-sm">Phone</p>
                    <a 
                      href={`tel:${site.links.phone}`}
                      className="text-white hover:text-forest-300 transition-colors"
                    >
                      {site.links.phone}
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-6 h-6 bg-forest-400 rounded-full mr-4 flex-shrink-0"></div>
                  <div>
                    <p className="text-white/60 text-sm">Location</p>
                    <p className="text-white">{site.links.address}</p>
                  </div>
                </div>
              </div>
            </GlassCard>
            
            <GlassCard>
              <h3 className="text-2xl font-semibold text-white mb-6">
                Follow Me
              </h3>
              
              <div className="flex space-x-4">
                <a 
                  href={site.links.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors backdrop-blur-sm"
                >
                  GitHub
                </a>
                <a 
                  href={site.links.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors backdrop-blur-sm"
                >
                  LinkedIn
                </a>
              </div>
            </GlassCard>
          </div>
          
          {/* Contact Form */}
          <div>
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;