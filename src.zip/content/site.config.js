export const site = {
  name: "Alex Johnson",
  title: "Frontend Developer (MERN)",
  bio: "Passionate MERN stack developer and recent bootcamp graduate with a love for creating beautiful, functional web applications. I specialize in React, Node.js, and modern JavaScript technologies.",
  
  links: {
    github: "https://github.com/alexjohnson",
    linkedin: "https://linkedin.com/in/alexjohnson",
    email: "alex.johnson@email.com",
    phone: "+1 (555) 123-4567",
    address: "San Francisco, CA"
  },

  cta: {
    github: "View GitHub",
    contact: "Contact Me"
  },

  skills: [
    "JavaScript", "React", "Node.js", "Express", "MongoDB", "HTML5", "CSS3", 
    "Tailwind CSS", "Git", "RESTful APIs", "Responsive Design", "Webpack"
  ],

  softSkills: [
    "Communication", "Teamwork", "Problem Solving", "Adaptability", 
    "Creativity", "Time Management", "Critical Thinking", "Leadership"
  ],

  projects: [
    {
      title: "E-Commerce Platform",
      description: "Full-stack MERN application with user authentication, shopping cart, and payment integration using Stripe API.",
      tech: ["React", "Node.js", "MongoDB", "Express", "Stripe"],
      live: "https://demo-ecommerce.netlify.app",
      github: "https://github.com/alexjohnson/ecommerce-app",
      cover: "/covers/ecommerce.png"
    },
    {
      title: "Task Management App",
      description: "Collaborative task management tool with real-time updates, drag-and-drop functionality, and team collaboration features.",
      tech: ["React", "Socket.io", "Node.js", "MongoDB"],
      live: "https://taskmaster-app.netlify.app",
      github: "https://github.com/alexjohnson/task-manager",
      cover: "/covers/taskmanager.png"
    },
    {
      title: "Weather Dashboard",
      description: "Interactive weather application with location-based forecasts, detailed weather metrics, and beautiful data visualizations.",
      tech: ["React", "OpenWeather API", "Chart.js", "CSS3"],
      live: "https://weather-insights.netlify.app",
      github: "https://github.com/alexjohnson/weather-app",
      cover: "/covers/weather.png"
    },
    {
      title: "Social Media Dashboard",
      description: "Analytics dashboard for social media management with data visualization, post scheduling, and engagement tracking.",
      tech: ["React", "Node.js", "D3.js", "MongoDB"],
      live: "https://social-dashboard.netlify.app",
      github: "https://github.com/alexjohnson/social-dashboard",
      cover: "/covers/social.png"
    },
    {
      title: "Recipe Finder",
      description: "Culinary discovery app with recipe search, meal planning, and shopping list generation using Spoonacular API.",
      tech: ["React", "Spoonacular API", "Local Storage", "CSS Grid"],
      live: "https://recipe-discovery.netlify.app",
      github: "https://github.com/alexjohnson/recipe-finder",
      cover: "/covers/recipe.png"
    },
    {
      title: "Fitness Tracker",
      description: "Personal fitness tracking application with workout logging, progress visualization, and goal setting features.",
      tech: ["React", "Firebase", "Chart.js", "PWA"],
      live: "https://fitness-journey.netlify.app",
      github: "https://github.com/alexjohnson/fitness-tracker",
      cover: "/covers/fitness.png"
    }
  ],

  experience: [
    {
      date: "2024",
      title: "Full-Stack Web Development Bootcamp Graduate",
      detail: "Completed intensive 24-week bootcamp covering MERN stack, algorithms, data structures, and modern web development practices."
    },
    {
      date: "2023-2024",
      title: "Freelance Web Developer",
      detail: "Built responsive websites and web applications for small businesses, focusing on user experience and performance optimization."
    },
    {
      date: "2023",
      title: "Career Transition to Tech",
      detail: "Started self-learning programming through online courses, building personal projects, and participating in coding challenges."
    }
  ]
}